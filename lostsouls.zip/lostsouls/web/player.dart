part of lostsouls;

class Player extends Body {
  final double _standardForce = 60000.0;
  final AudioManager _audioManager;
  final Random rnd = new Random();
  double _totalAnchorFactor = 0.0;

  Player(final Vector2D position, final Vector2D lookDirection, this._audioManager) : super(18.0, position, new Vector2D.zero(), new Vector2D.zero(), lookDirection, PI * 0.8){
    _collisionHandler = _handleCollisions;
  }

  void _handleCollisions(final Vector2D velocityBefore, final Vector2D velocityAfter) {
    if (velocityBefore.length > 25.0) {
      _audioManager.play("wallhit");
    }
  }

  void processInput(final double totalElapsed, final double elapsed, final Level level, final List<Body> entities, final Keyboard keyboard) {
    if (keyboard.isPressed(KeyCode.W)) {
      forces.add(lookDirection * (_standardForce / (1 + size)) * (1.0 - _totalAnchorFactor));
      // If throttle is on, eject some smoke particles looking like fire.
      if (rnd.nextDouble() > 0.125)
        entities.add(new Smoke(position, normalize(lookDirection) * 12.0 * -acceleration.length, 0.55 * size));
    }
    else {
      if (velocity.length < 0.001)
        velocity.clear();
    }

    if (keyboard.isPressed(KeyCode.S))
      forces.add(lookDirection * (-0.5 * _standardForce / (1 + size)) * (1.0 - _totalAnchorFactor));

    if (keyboard.isPressed(KeyCode.PERIOD) || keyboard.isPressed(KeyCode.COMMA)) {
      final Vector2D perpendicular = cross(lookDirection);
      if (keyboard.isPressed(KeyCode.COMMA))
        forces.add(perpendicular * (0.45 * _standardForce / (1 + size)));
      else
        forces.add(perpendicular * (-0.45 * _standardForce / (1 + size)));
    }

    if (keyboard.isPressed(KeyCode.A))
      lookDirection = rotate(lookDirection, -(32 * elapsed / (1 + size)));

    if (keyboard.isPressed(KeyCode.D))
      lookDirection = rotate(lookDirection,  (32 * elapsed / (1 + size)));

    _totalAnchorFactor = 0.0;
  }

  void addAnchorFactor(final double factor) {
    _totalAnchorFactor = max(min(0.75, _totalAnchorFactor + factor), 0.0);
  }

  void render(final Renderer renderer) {
    renderer.renderEntity(this, 'blue', _totalAnchorFactor > 0 ? 'red' : 'white', 'black');
  }
}

