part of lostsouls;

class StateFade extends GameState {
  final GameState _from;
  final GameState _to;
  final double _fadeTime;
  final String _color;

  StateFade(final Keyboard keyboard, final Renderer renderer, final AudioManager manager, this._from, this._to, this._fadeTime, this._color) : super(keyboard, renderer, manager) {
  }

  GameState _update(final double elapsed) {
    super._update(elapsed);

    if (_totalElapsed >= (2.0 * _fadeTime)) {
      return _to;
    }

    return this;
  }

  void _render() {
    if (_totalElapsed < _fadeTime) {
      final f = _totalElapsed / _fadeTime;
      _from._render();
      _renderer..pushGlobalAlpha(f)
               ..fillFullRect(_color);
    }
    else  {
      final f = (_totalElapsed - _fadeTime) / _fadeTime;
      _to._render();
      _renderer..pushGlobalAlpha(1.0 - f)
               ..fillFullRect(_color);
    }
    _renderer.popGlobalAlpha();
  }
}