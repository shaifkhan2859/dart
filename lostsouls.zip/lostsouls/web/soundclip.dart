part of lostsouls;

class SoundClip {
  final String _name;
  final String _url;
  final bool _singleton;

  AudioContext _context;
  AudioBuffer _buffer;
  bool _isPlaying;
  int _numberOfPlayers;

  bool _broken = false;

  AudioBufferSourceNode _node;
  GainNode _gainNode;

  SoundClip(this._name, this._url, this._singleton);

  AudioBufferSourceNode _createNode() {
    final AudioBufferSourceNode source = _context.createBufferSource();
    source.buffer = _buffer;
    source.connectNode(_context.destination, 0, 0);
    return source;
  }

  void _playSingleton() {
    if (_node == null || (_node != null && _node.playbackState == 3)) {
      _node = _context.createBufferSource();
      _node.buffer = _buffer;
      _gainNode = _context.createGain();
      _node.connectNode(_gainNode, 0, 0);
      _gainNode.connectNode(_context.destination, 0, 0);
      _node.noteOn(0);
    }
  }

  void play() {
    if (_broken) {
      print("Tried to play $_name but it's broken");
      return;
    }

    if (_singleton)
      _playSingleton();
    else {
      final AudioBufferSourceNode node = _createNode();
      node.noteOn(0);
    }
  }

  void stop() {
    if (_node != null) {
      _node.noteOff(0);
      _node = null;
      _gainNode = null;
    }
    else
      if (!_singleton)
        throw new Exception("Cannot stop non-singleton sound clip $_name");
  }

  void setGain(final double value) {
    if (_singleton) {
      if (_gainNode != null)
        _gainNode.gain.value = value;
    }
    else
      throw new Exception("Cannot set gain on non-singleton sound clip $_name");
  }

  void resetGain() {
    if (_singleton) {
      if (_gainNode != null) {
        _gainNode.gain.value = _gainNode.gain.defaultValue;
      }
    }
    else
      throw new Exception("Cannot set gain on non-singleton sound clip $_name");
  }

  get isPlaying => _node != null && _node.playbackState == 1;
}
