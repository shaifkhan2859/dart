part of lostsouls;

class StateGame extends GameState {
  
  static bool _isMusicAllowed = true;

  final int _levelIndex;
  GameController _controller;

  StateGame(final Keyboard keyboard, final Renderer renderer, final AudioManager manager, this._levelIndex) : super(keyboard, renderer, manager) {
    _controller = createLevel(_levelIndex, 800, 600, manager, renderer.context);
  }

  void _initialize() {
    if (_isMusicAllowed)
      _audioManager.play("music");

    querySelector("#areaTime").style.visibility = "visible";
    querySelector("#areaScoreB").style.visibility = "visible";
    querySelector("#areaScoreT").style.visibility = "visible";
  }

  GameState _update(double elapsed) {
    super._update(elapsed);

    if (_keyboard.isPressed(KeyCode.M)) {
      _audioManager.play("music");
      _isMusicAllowed = true;
    }

    if (_keyboard.isPressed(KeyCode.N)) {
      _audioManager.stop("music");
      _isMusicAllowed = false;
    }

    _controller.update(elapsed);

    if (!_controller.entities.any((e) => e is LostSoul)) {
      _audioManager.play("levelwon");
      return new StateFade(_keyboard, _renderer, _audioManager, this, new StateNewLevel(_keyboard, _renderer, _audioManager, _levelIndex + 1), 1.0, Colors.backgroundMain);
    }
    if (_controller._getTimeLeft() <= 0.0)
      return new StateGameOver(_keyboard, _renderer, _audioManager);

    return this;
  }

  void _render() {
    
    _controller.render(_totalElapsed);

    final double fadeOutStartTime = 10.0;
    final double timeLeft = _controller._getTimeLeft();
    if (timeLeft <= fadeOutStartTime) {
      final double fraction = 1.0 - timeLeft / fadeOutStartTime;

      _renderer.pushGlobalAlpha(fraction);
      _renderer.fillFullRect(Colors.backgroundGameOver);
      _renderer.popGlobalAlpha();
    }
  }
}
