part of lostsouls;

/**
 * Represents a line between two points.
 */
class Segment {
  final Vector2D _a;
  final Vector2D _b;

  Segment(this._a, this._b);

  String toString() => '$_a-$_b';

  get a2b => _b - _a;
  get endPoints => [_a, _b];
  get length => a2b.length;

  bool containsEndPoint(Vector2D point) {
    return _a == point || _b == point;
  }

  bool contains(Vector2D point) {
    if (containsEndPoint(point))
      return true;

    final Vector2D aToPoint = point - _a;

    final double angle = angleBetween(aToPoint, a2b);
    if (fltEquals(angle, 0.0)) {
      return aToPoint.length <= a2b.length;
    }
    else {
      return false;
    }
  }

  double distanceToPoint(Vector2D point) {
    final Vector2D la = new Vector2D(0.0, 0.0);
    final Vector2D lb = _b - _a;
    final Vector2D lp = point - _a;

    final Vector2D aToPoint = lp - la;
    final Vector2D projection = project(aToPoint, lb);
    final Vector2D segmentPoint = _a + (la + projection);

    if (contains(segmentPoint)) {
        return distanceBetween(point, segmentPoint);
    }
    else {
        return double.MAX_FINITE;
    }
  }
}

SegmentIntersection findIntersection(Segment a, Segment b) {
  final double x1 = a._a.x;
  final double y1 = a._a.y;
  final double x2 = a._b.x;
  final double y2 = a._b.y;

  final double x3 = b._a.x;
  final double y3 = b._a.y;
  final double x4 = b._b.x;
  final double y4 = b._b.y;

  final double denominator = (x1 - x2)*(y3 - y4) - (y1 - y2)*(x3 - x4);
  if (denominator == 0.0)
    return new SegmentIntersection(a, b, false, null, false, false);

  final double xNominator = (x1*y2 - y1*x2)*(x3 - x4) - (x1 - x2)*(x3*y4 - y3*x4);
  final double yNominator = (x1*y2 - y1*x2)*(y3 - y4) - (y1 - y2)*(x3*y4 - y3*x4);

  final double px = xNominator / denominator;
  final double py = yNominator / denominator;

  final Vector2D point = new Vector2D(px, py);
  return new SegmentIntersection(a, b, true, point, a.contains(point), b.contains(point));
}