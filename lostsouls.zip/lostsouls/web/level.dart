part of lostsouls;

int _shadowAreaCompare(final Vector2D lhs, final Vector2D rhs, final Segment wall, final Segment source) {
  if (lhs == wall._a)
    return 1;

  if (rhs == wall._a)
    return -1;

  if (lhs == wall._b)
    return -1;

  if (rhs == wall._b)
    return 1;

  final Vector2D p2lhs = lhs - source._a;
  final Vector2D p2rhs = rhs - source._a;

  final double lhsAngle = angleBetween(p2lhs, source.a2b);
  final double rhsAngle = angleBetween(p2rhs, source.a2b);

  if (lhsAngle < rhsAngle) {
    return 1;
  }
  else {
    if (lhsAngle > rhsAngle) {
      return -1;
    }
  }

  return 0;
}

int _outOfViewAreaCompare(final Vector2D lhs, final Vector2D rhs, final Vector2D origin, final Vector2D direction, final Vector2D rPoint, final Vector2D lPoint) {
  if (lhs == origin)
    return 1;

  if (rhs == origin)
    return -1;

  if (lhs == rPoint)
    return -1;

  if (rhs == rPoint)
    return 1;

  if (lhs == lPoint)
    return 1;

  if (rhs == lPoint)
    return -1;

  final Vector2D vl = normalize(lhs - origin);
  final Vector2D vr = normalize(rhs - origin);

  final double al = wrappedAngleBetween(vl, direction);
  final double ar = wrappedAngleBetween(vr, direction);

  return al < ar ? 1 : -1;
}


class Level {
  final String name;
  final List<Segment> bounds;
  final List<Segment> walls;

  Level(this.name, this.bounds, this.walls);

  List<Vector2D> calculateShadowArea(Body entity, Segment wall) {
    final List<Vector2D> polygonPoints = new List<Vector2D>();
    final List<Vector2D> endpoints = wall.endPoints;

    for(var i = 0; i < endpoints.length; ++i) {
      final Vector2D wallPoint = endpoints[i];
      final Segment observerToWallEndPoint = new Segment(entity.position,  wallPoint);

      polygonPoints.add(wallPoint);
      for(var j = 0; j < bounds.length; ++j) {
        final Segment bound = bounds[j];
        final SegmentIntersection wallIntersection = findIntersection(observerToWallEndPoint, bound);
        if (wallIntersection.isIntersection && wallIntersection.pointIsOnB) {
          final Vector2D d = wallIntersection.point - entity.position;
          final double a = angleBetween(observerToWallEndPoint.a2b, d);
          if (fltEquals(0.0, angleBetween(observerToWallEndPoint.a2b, wallIntersection.point - entity.position))) {
            polygonPoints.add(wallIntersection.point);
          }
        }
      }
    }

    final Vector2D e2epA = wall._a - entity.position;
    final Vector2D e2epB = wall._b - entity.position;

    for(var i = 0; i < bounds.length; ++i) {
      final Segment bound = bounds[i];
      final Segment observerToBoundryCornerA = new Segment(entity.position, bound._a);

      final double a1 = signedAngleBetween(e2epA, observerToBoundryCornerA.a2b);
      final double a2 = signedAngleBetween(e2epB, observerToBoundryCornerA.a2b);

      final SegmentIntersection cornerIntersection = findIntersection(wall, observerToBoundryCornerA);
      if (cornerIntersection.isIntersection && cornerIntersection.pointIsOnA && !fltEquals(0.0, angleBetween(observerToBoundryCornerA.a2b, entity.position - cornerIntersection.point))) {
          polygonPoints.add(observerToBoundryCornerA._b);
      }
    }

    final Segment source = new Segment(entity.position, wall._a);
    polygonPoints.sort((lhs, rhs) => _shadowAreaCompare(lhs, rhs, wall, source));
    return polygonPoints;
  }

  List<Vector2D> calculateOutOfViewArea(Body entity) {
    final List<Vector2D> polygonPoints = new List<Vector2D>();
    polygonPoints.add(entity.position);

    final Vector2D rDir = rotate(entity.lookDirection, entity.fieldOfView / 2.0);
    final Vector2D lDir = rotate(entity.lookDirection, -entity.fieldOfView / 2.0);

    final Segment rSegment = new Segment(entity.position, entity.position + rDir);
    final Segment lSegment = new Segment(entity.position, entity.position + lDir);

    Vector2D lPoint = null;
    Vector2D rPoint = null;
    for(var i = 0; i < bounds.length; ++i) {
      final Segment bound = bounds[i];
      final SegmentIntersection rBoundIntersection = findIntersection(bound, rSegment);
      if (rBoundIntersection.isIntersection && rBoundIntersection.pointIsOnA && fltEquals(0.0, angleBetween(rDir, rBoundIntersection.point - entity.position))) {
        rPoint = rBoundIntersection.point;
        polygonPoints.add(rBoundIntersection.point);
      }

      final SegmentIntersection lBoundIntersection = findIntersection(bound, lSegment);
      if (lBoundIntersection.isIntersection && lBoundIntersection.pointIsOnA && fltEquals(0.0, angleBetween(lDir, lBoundIntersection.point - entity.position))) {
        lPoint = lBoundIntersection.point;
        polygonPoints.add(lBoundIntersection.point);
      }

      final Vector2D toCorner = bound._a - entity.position;
      final double angle = angleBetween(toCorner, entity.lookDirection);
      if (angle.abs() > entity.fieldOfView / 2.0) {
        polygonPoints.add(bound._a);
      }
    }

    final Vector2D direction = normalize(entity.lookDirection);
    final Vector2D origin = entity.position;
    polygonPoints.sort((lhs, rhs) => _outOfViewAreaCompare(lhs, rhs, origin, direction, rPoint, lPoint));
    return polygonPoints;
  }
}