part of lostsouls;

class ShadowSet {
  final List<Vector2D> _shadow;
  final String _color;
  final double _distance;

  ShadowSet(this._shadow, this._color, this._distance);
}

class GameController {
  final Renderer renderer;
  final Keyboard keyboard;
  final AudioManager audioManager;
  Level level;
  List<Body> entities;
  Body focused = null;
  double totalElapsed = 0.0;

  int _toSave;
  double _allowedTime;

  GameController(this.renderer, this.keyboard, this.audioManager, this.level, this.entities, this._allowedTime) {
    _toSave = entities.where((e) => e is LostSoul).length;
  }

  double _getTimeLeft() {
    return _allowedTime - totalElapsed;
  }

  void update(final double elapsed) {
    var newEntities = [];
    this.totalElapsed += elapsed;

    for(var i = 0; i < entities.length; ++i) {
        var entity = entities[i];
        entity.processInput(totalElapsed, elapsed, level, entities, keyboard);
        var shouldDelete = entity.update(totalElapsed, elapsed, level);
        if (!shouldDelete) {
            newEntities.add(entity);
        }

        for(var j = 0; j < entity.additionalEntities.length; ++j) {
            newEntities.add(entity.additionalEntities[j]);
        }
        entity.additionalEntities = [];
    }
    this.entities = newEntities;
  }



  void render(final double totalElapsed) {
    renderer.clip();
    renderer.clearAll(Colors.backgroundMain);

    // inner walls
    for(var i = 0; i < level.walls.length; ++i) {
      renderer.drawSegment(level.walls[i], 'white', 4.0);
    }

    for(var i = 0; i < entities.length; ++i) {
      var entity = entities[i];
      entity.render(renderer);
    }

    if (focused != null) {
      double fade = 1.0;
      final double fadeInTime = 3.0;
      if (totalElapsed < fadeInTime) {
        fade = totalElapsed / fadeInTime;
      }

      // shadow cast by inner walls
      final List<ShadowSet> sets = new List<ShadowSet>();
      for(int i = 0; i < level.walls.length; ++i) {
        final Segment wall = level.walls[i];
        final double angle = 128 + 128.0 * wall.a2b.angle / (2.0*PI);

        String s = angle.abs().toInt().toRadixString(16);
        if (s.length == 1)
          s = "0${s}";

        String c;
        switch((i ~/ 4) % 6) {
          case 0: c = "#${s}0000".toUpperCase(); break;
          case 1: c = "#00${s}00".toUpperCase(); break;
          case 2: c = "#0000${s}".toUpperCase(); break;
          case 3: c = "#${s}00${s}".toUpperCase(); break;
          case 4: c = "#00${s}${s}".toUpperCase(); break;
          case 5: c = "#${s}${s}${s}".toUpperCase(); break;
        }

        final List<Vector2D> shadow = level.calculateShadowArea(focused, level.walls[i]);
        final Vector2D a = focused.position - wall._a;
        final Vector2D b = focused.position - wall._b;

        sets.add(new ShadowSet(shadow, c, (a.length + b.length) / 2.0));
      }

      sets.sort((a, b) => (b._distance - a._distance).toInt());

      for(int i = 0; i < sets.length; ++i) {
        final ShadowSet set = sets[i];
        renderer.fillPolygon(set._shadow, set._color);
      }

      focused.render(renderer);
    }

    _renderRemainingLostSouls();

    _renderRemainingTime();
  }

  void _renderRemainingLostSouls() {
    final int saved = _toSave - entities.where((e) => e is LostSoul).length;
    String b = "";
    for(int i = 0; i < _toSave; ++i)
      b += "Œ";

    String t = "";
    for(int i = 0; i < saved; ++i)
      t += "Œ";

    querySelector("#areaScoreB").text = b;
    querySelector("#areaScoreT").text = t;
  }

  void _renderRemainingTime() {
    final int seconds = _getTimeLeft().round();
    final int fraction = ((_getTimeLeft()) * 100).round() % 100;
    final String padding = fraction < 10 ? "0" : "";
    final String timeLeft = "${seconds}.${padding}${fraction}s";

    querySelector("#areaTime").text = timeLeft;
    querySelector("#areaTime").style.visibility = "visible";
    querySelector("#areaGameTextMain").style.visibility = "hidden";
  }
}

