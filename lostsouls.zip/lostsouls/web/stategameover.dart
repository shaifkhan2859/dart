part of lostsouls;

class StateGameOver extends GameState {

  final double timeout = 4.0;
  bool timedOut = false;

  StateGameOver(final Keyboard keyboard, final Renderer renderer, final AudioManager audioManager) : super(keyboard, renderer, audioManager) {
  }

  void _initialize() {
    querySelector("#areaTime").style.visibility = "hidden";
  }

  GameState _update(double elapsed) {
    super._update(elapsed);

    if (_totalElapsed > timeout && _keyboard.isPressed(KeyCode.SPACE))
      return new StateInit(_keyboard, _renderer, _audioManager);

    return this;
  }

  void _render() {
    _renderer.clip();
    _renderer.clearAll(Colors.backgroundGameOver);

    if (_totalElapsed > timeout) {
      if (!timedOut) {
        _audioManager.play("gameover");
        _audioManager.stop("music");
      }
      timedOut = true;
      querySelector("#areaGameTextMain").text = "PRESS SPACE TO RESET";
    }
    else {
      _audioManager.setGain("music", 1.0 - (_totalElapsed / timeout));
      querySelector("#areaGameTextMain").text = "GAME OVER";
    }

    querySelector("#areaGameTextMain").style.visibility = "visible";
    querySelector("#areaTime").style.visibility = "hidden";
  }
}
