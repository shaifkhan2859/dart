part of lostsouls;


Vector2D _getRandomPosition(Random rnd, Vector2D ul, Vector2D lr) {
  return new Vector2D(
      ul.x + rnd.nextDouble() * (lr.x - ul.x),
      ul.y + rnd.nextDouble() * (lr.y - ul.y));
}

Vector2D _getRandomUnitVector(Random rnd) {
  return new Vector2D.polar(rnd.nextDouble() * 2.0 * PI, 1.0);
}

bool _isFarAway(Vector2D a, Vector2D b, double requiredDistance) {
  return distanceBetween(a, b) > requiredDistance;
}

bool _isFarAwayFromEachOther(Body a, Body b) {
  return _isFarAway(a.position, b.position, (a.size + b.size) * 2.0);
}

GameController createLevel(int levelId, int width, int height, AudioManager audioManager, CanvasRenderingContext2D context) {
  Random rnd = new Random(levelId);

  double w = width.roundToDouble();
  double h = height.roundToDouble();
  var bounds = [];
  bounds.add(new Segment(new Vector2D(0.0, 0.0), new Vector2D(w, 0.0)));
  bounds.add(new Segment(new Vector2D(w, 0.0), new Vector2D(w, h)));
  bounds.add(new Segment(new Vector2D(w, h), new Vector2D(0.0, h)));
  bounds.add(new Segment(new Vector2D(0.0, h), new Vector2D(0.0, 0.0)));

  Vector2D ul = new Vector2D(0.0, 0.0);
  Vector2D lr = new Vector2D(w, h);

  var player = new Player(new Vector2D.zero(), _getRandomUnitVector(rnd), audioManager);
  Vector2D playerSize = new Vector2D(player.size, player.size);
  player.position = _getRandomPosition(rnd, ul + playerSize, lr - playerSize);

  var walls = [];

  var keyboard = new Keyboard();
  var entities = [ ];

  entities.add(new Home(lr));
  entities.add(player);

  // Create lost souls
  for(int i = 0; i < levelId; ++i) {
    LostSoul soul = new LostSoul(new Vector2D.zero(), _getRandomUnitVector(rnd), 16.0 + rnd.nextDouble() *16.0, audioManager);
    Vector2D soulSize = new Vector2D(soul.size, soul.size);
    bool okPosition = false;
    while(!okPosition) {
      okPosition = true;
      Vector2D p = _getRandomPosition(rnd, ul + soulSize, lr - soulSize);
      soul.position = p;

      for(int j = 0; j < entities.length; ++j) {
        Body body = entities[j];
        okPosition = okPosition && _isFarAwayFromEachOther(soul, body);
      }
    }
    entities.add(soul);
  }

  // Create anchormen
  for(int i = 0; i < max(1, levelId * 0.4); ++i) {
    final AnchorMan man = new AnchorMan(new Vector2D.zero(), _getRandomUnitVector(rnd), audioManager);
    final Vector2D soulSize = new Vector2D(man.size, man.size);
    bool okPosition = false;
    while(!okPosition) {
      okPosition = true;
      Vector2D p = _getRandomPosition(rnd, ul + soulSize, lr - soulSize);
      man.position = p;

      for(int j = 0; j < entities.length; ++j) {
        Body body = entities[j];
        okPosition = okPosition && _isFarAwayFromEachOther(man, body);
      }
    }
    entities.add(man);
  }



  for(int i = 0; i < 8 + rnd.nextInt(8) ; ++i) {
    bool isOk = false;
    while(!isOk) {
      isOk = true;
      final double size = 20.0 + rnd.nextDouble() * 40.0;
      final Vector2D center = _getRandomPosition(rnd, ul, lr);

      for(int j = 0; j < entities.length; ++j) {
        final Body body = entities[j];
        if (!_isFarAway(center, body.position, size + body.size * 2.0))
          isOk = false;
      }

      final double angle = rnd.nextDouble() * 2.0 * PI;
      final Vector2D a = center + new Vector2D.polar(angle + 0.0 * (2.0 * PI / 4.0), size);
      final Vector2D b = center + new Vector2D.polar(angle + 1.0 * (2.0 * PI / 4.0), size);
      final Vector2D c = center + new Vector2D.polar(angle + 2.0 * (2.0 * PI / 4.0), size);
      final Vector2D d = center + new Vector2D.polar(angle + 3.0 * (2.0 * PI / 4.0), size);


      for(int w = 0; w < walls.length; ++w) {
        final Segment wall = walls[w];

        isOk = isOk && _isFarAway(wall._a, a, size);
        isOk = isOk && _isFarAway(wall._a, b, size);
        isOk = isOk && _isFarAway(wall._a, c, size);
        isOk = isOk && _isFarAway(wall._a, d, size);
        isOk = isOk && _isFarAway(wall._b, a, size);
        isOk = isOk && _isFarAway(wall._b, b, size);
        isOk = isOk && _isFarAway(wall._b, c, size);
        isOk = isOk && _isFarAway(wall._b, d, size);
      }

      if (!isOk)
        continue;

      walls.add(new Segment(a, b));
      walls.add(new Segment(b, c));
      walls.add(new Segment(c, d));
      walls.add(new Segment(d, a));
      isOk = true;
    }
  }

  final Level level = new Level(levelId.toString(), bounds, walls);
  final Renderer renderer = new Renderer(context, width, height);

  final GameController controller = new GameController(renderer, keyboard, audioManager, level, entities, 20.0 + levelId * 20.0 + (levelId * 5));
  controller.focused = player;
  return controller;
}

