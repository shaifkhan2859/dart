part of lostsouls;

class ColorAnimationPoint {
  final double start;
  final double end;
  final String from;
  final String to;
  
  ColorAnimationPoint(this.start, this.end, this.from, this.to);

  
  double _getFraction(final double elapsed) {
    if (elapsed > start) {
      if (elapsed < end) {
        return (elapsed - start) / (end - start);    
      }
      else
        return 1.0;
    }
    return 0.0;
  }

  String getColorPart(int color) {
    final String str = color.toRadixString(16);
    return str.length == 1 ? "0${str}" : str;
  }

  
  String getColor(final double elapsed) {
    final double ff = 1.0 - _getFraction(elapsed);         
    final double tf = 1.0 - ff;
    
    String result = "#";
    for(int i = 0; i < 3; ++i) {
      final int a = 1 + i * 2;
      final int b = a + 2;
      final String fps = from.substring(a, b);  
      final String tps = to.substring(a, b);  
      
      final int fp = int.parse(fps, radix: 16);
      final int tp = int.parse(tps, radix: 16);
      
      final double part = ff * fp.toDouble() + tf * tp.toDouble();
      final String cp =getColorPart((part).toInt());
      result = result + cp;
    }
  
    return result; 
  }
}

class ColorAnimation {
  List<ColorAnimationPoint> _points;
  
  ColorAnimation(this._points);

  String getColor(final double elapsed) {
    Iterable<ColorAnimationPoint> applicablePoints = _points.where((cp) => elapsed >= cp.start && elapsed < cp.end);
    if (applicablePoints.length == 0)
      return _points.last.getColor(elapsed);
    else
      return applicablePoints.single.getColor(elapsed);
  }
}


class Smoke extends Body {
  
  double _lifeSpan = 0.75;
  double _elapsedLife = 0.0;
  
  ColorAnimation colorAnimation;
  
  Smoke(final Vector2D position, final Vector2D velocity, final double size) : super(size, position, new Vector2D.zero(), velocity, new Vector2D(0.0, 1.0), 0.0) {
    colorAnimation = new ColorAnimation(
    [
     new ColorAnimationPoint(0.0, 0.20, "#FFFF00", "#FF0000"),
     new ColorAnimationPoint(0.20, 0.5, "#FF0000", "#000000"),
     new ColorAnimationPoint(0.5, 0.75, "#000000", "#FFFFFF"),
    ]    
    );
  }

  bool update(final double totalElapsed, final double elapsed, final Level level) {
   super.update(totalElapsed, elapsed, level);
   _elapsedLife += elapsed;
   return _elapsedLife > _lifeSpan;
  }
  
  void render(Renderer renderer) {
    final double f = (1.0 - _elapsedLife / _lifeSpan);
    renderer.pushGlobalAlpha(f);
    
    // #FFFF00
    // #FF0000
    // #000000
    //ColorAnimationPoint pa = new ColorAnimationPoint(0.0, _lifeSpan, "#FFFF00", "#FF0000");
    
    
    //final double y = max(0, _elapsedLife - _lifeSpan
    
    renderer.fillCircle(position, 8.0 + size * f, colorAnimation.getColor(_elapsedLife));
    renderer.popGlobalAlpha();
  }
}