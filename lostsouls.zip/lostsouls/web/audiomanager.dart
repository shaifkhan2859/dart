part of lostsouls;

typedef void OnAudioLoaded(final double loaded);
typedef void OnAllAudioLoaded(final List<SoundClip> clips);

class AudioManager {
  final AudioContext _context;
  final List<SoundClip> _clips;
  final OnAudioLoaded _onAudioLoadedCallback;
  final OnAllAudioLoaded _onAllAudioLoadedCallback;
  final HashSet<int> _playing = new HashSet<int>();

  int _numberOfLoadedBuffers = 0;

  AudioManager(this._context, this._clips, this._onAudioLoadedCallback, this._onAllAudioLoadedCallback) {
    _loadBuffers();
  }

  void _loadBuffers() {
    for (var i = 0; i < _clips.length; i++) {
      _clips[i]._context = _context;
      _loadBuffer(_clips[i], i);
    }
  }

  void _loadBuffer(final SoundClip clip, final int index) {
    final HttpRequest request = new HttpRequest();
    request.open("GET", clip._url, async: true);
    request.responseType = "arraybuffer";
    request.onLoadEnd.listen((e) => _onBufferLoaded(request, clip, index));
    request.onError.listen((e) => _handleError(e, clip));

    try {
      request.send();
    }
    catch(ex) {
      clip._broken = true;
      _notify(clip);
    }
  }

  void _handleError(ProgressEvent e, SoundClip clip) {
    clip._broken = true;
    e.stopImmediatePropagation();
    e.stopPropagation();
  }

  void _notify(final SoundClip clip) {
    final int loaded = _clips.where((c) => c._buffer != null || c._broken).length;
    final double fraction = loaded.toDouble() / _clips.length;
    _onAudioLoadedCallback(fraction);

    if (loaded == _clips.length) {
      _onAllAudioLoadedCallback(_clips);
    }
  }

  void _onBufferLoaded(final HttpRequest request, final SoundClip clip, final int index) {
    _context.decodeAudioData(request.response).then((final AudioBuffer buffer) {
      if (buffer == null) {
        clip._broken = true;
      }
      else {
        clip._buffer = buffer;
      }
      _notify(clip);
    });
  }

  SoundClip _getClip(final String name) {
    return _clips.where((c) => c._name == name).single;
  }

  void play(final String name) {
    _getClip(name).play();
  }

  void stop(final String name) {
    _getClip(name).stop();
  }

  void setGain(final String name, final double value) {
    _getClip(name).setGain(value);
  }

  void resetGain(final String name) {
    _getClip(name).resetGain();
  }

  bool isPlaying(final String name) {
    return _getClip(name).isPlaying;
  }
}