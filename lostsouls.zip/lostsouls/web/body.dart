part of lostsouls;

typedef void OnCollision(final Vector2D velocityBefore, final Vector2D velocityAfter);


class Body {

  double size = 20.0;
  Vector2D position = new Vector2D(0.0, 0.0);
  Vector2D acceleration = new Vector2D(0.0, 0.0);
  Vector2D velocity = new Vector2D(0.0, 0.0);

  Vector2D lookDirection = new Vector2D(1.0, 0.0);
  double fieldOfView = PI * 0.5;
  List<Vector2D> forces = new List<Vector2D>();

  List<Body> additionalEntities = [];
  double restitution = 1.5;
  double worldFriction = 0.01;
  bool respectsBounds = true;
  Segment lastCollision = null;
  bool isDead = false;

  // This delegate is called when the Body bumps into a wall
  // it allows each type of body to, for example, make a sound
  OnCollision _collisionHandler = (b, a) => { };

  Body(this.size, this.position, this.acceleration, this.velocity, Vector2D lookDirection, this.fieldOfView){
    this.lookDirection = normalize(lookDirection);
  }

  void processInput(double totalElapsed, double elapsed, Level level, List<Body> entities, Keyboard keyboard) {
  }

  bool processCollision(final Segment wall, final bool includeEndPoints, final Vector2D newPosition) {
    final Vector2D velocityBefore = new Vector2D(velocity.x, velocity.y);

    // Prevent tuneling
    final Segment oldToNew = new Segment(position, newPosition);
    final SegmentIntersection intersection = findIntersection(wall, oldToNew);
    if (intersection.isIntersection && intersection.pointIsOnA && intersection.pointIsOnB) {
        position = intersection.point + (normalize(oldToNew.a2b) * -size);

        Vector2D n = cross(wall.a2b);
        if (angleBetween(n, oldToNew.a2b) > PI / 2.0)
            n = n * -1.0;

        final Vector2D velocityProjection = project(velocity, normalize(n));
        velocity = velocity - (velocityProjection * restitution);
        lastCollision = wall;
        _collisionHandler(velocityProjection, velocity);
        return true;
    }

    if (includeEndPoints) {
        final List<Vector2D> endPoints = wall.endPoints;
        for (var i = 0; i < endPoints.length; ++i) {
            final Vector2D endPoint = endPoints[i];
            final Vector2D posToEndPoint = endPoint - position;
            if (posToEndPoint.length < size && angleBetween(posToEndPoint, velocity) < PI / 2.0) {
                final Vector2D velocityProjection = project(velocity, posToEndPoint);
                velocity = velocity - (velocityProjection * restitution);
                lastCollision = wall;
                _collisionHandler(velocityProjection, velocity);
                return true;
            }
        }
    }

    final Vector2D aToPos = position - wall._a;
    final Vector2D projection = project(aToPos, wall.a2b);

    final Vector2D contactPoint = wall._a + projection;
    final Vector2D posToCp = contactPoint - position;

    final Vector2D aToCp = contactPoint - wall._a;
    if (aToCp.length > wall.length)
      return false;

    if (!fltEquals(0.0, angleBetween(aToCp, wall.a2b)))
        return false;

    if (posToCp.length < size && angleBetween(posToCp, velocity) < PI / 2.0) {
        final Vector2D velocityProjection = project(velocity, posToCp);
        velocity = velocity - (velocityProjection * restitution);
        lastCollision = wall;
        _collisionHandler(velocityProjection, velocity);
        return true;
    }

    return false;
  }

  bool update(final double totalElapsed, final double elapsed, final Level level) {

    velocity = velocity * (1.0 - worldFriction);
    acceleration.clear();
    for (var i = 0; i < forces.length; ++i) {
        var force = forces[i];
        acceleration = acceleration + (force * (elapsed / (1 + size)));
    }

    velocity = velocity + acceleration;

    final Vector2D newPosition = position + (velocity * elapsed);

    // collisions
    lastCollision = null;
    if (!fltEquals(0.0, velocity.length)) {

        if (respectsBounds) {
            for (var i = 0; i < level.bounds.length; ++i) {
               processCollision(level.bounds[i], false, newPosition);
            };
        }

        for (var i = 0; i < level.walls.length; ++i) {
            processCollision(level.walls[i], true, newPosition);
        };
    }

    position = position + (velocity * elapsed);

    forces = [];
    return isDead;
  }

  /* dummy implementation for debugging, should never be called */
  void render(Renderer renderer) {
    renderer.drawCircle(position, 16.0, "magenta");
  }
}