part of lostsouls;

bool fltEquals(double lhs, double rhs) {
  return (lhs - rhs).abs() < 0.000001;
}

double sign(double d) {
  return d < 0.0 ? -1.0 : 1.0;
}

class Vector2D {
  double x;
  double y;

  Vector2D(this.x, this.y);

  Vector2D.polar(final double theta, final double radius) {
    x = cos(theta) * radius;
    y = sin(theta) * radius;
  }

  Vector2D.zero() {
    x = 0.0;
    y = 0.0;
  }

  String toString() => '($x, $y)';

  void clear() {
    x = 0.0;
    y = 0.0;
  }

  get length => sqrt(x*x + y*y);
  get angle => atan2(x, y);

  get hashCode => (x * y).hashCode;

  operator ==(final Vector2D other) {
    return fltEquals(x, other.x) && fltEquals(y, other.y);
  }

  Vector2D operator +(final Vector2D rhs) {
    return new Vector2D(x + rhs.x, y + rhs.y);
  }

  Vector2D operator -(final Vector2D rhs) {
    return new Vector2D(x - rhs.x, y - rhs.y);
  }

  Vector2D operator *(final double factor) {
    return new Vector2D(x * factor, y * factor);
  }
}

Vector2D normalize(Vector2D v) {
  var l = v.length;
  return new Vector2D(v.x / l, v.y / l);
}

double dot(Vector2D lhs, Vector2D rhs) {
  return lhs.x*rhs.x + lhs.y*rhs.y;
}

/* Technically this is probably not a true cross-product */
Vector2D cross(Vector2D vector) {
  return new Vector2D(vector.y, -vector.x);
}

double distanceBetween(Vector2D lhs, Vector2D rhs) {
  final Vector2D delta = lhs - rhs;
  return delta.length;
}

double angleBetween(Vector2D lhs, Vector2D rhs) {
  final double d = dot(lhs, rhs) / (lhs.length*rhs.length);
  if (d < -1.0)
    return PI;

  if (d > 1.0)
    return 0.0;

  return acos(d);
}

double signedAngleBetween(Vector2D lhs, Vector2D rhs) {
  final Vector2D na = normalize(lhs);
  final Vector2D nb = normalize(rhs);

  return atan2(nb.y, nb.x) - atan2(na.y, na.x);
}

double wrappedAngleBetween(Vector2D lhs, Vector2D rhs) {
  double angle = signedAngleBetween(lhs, rhs);
  if (angle < 0)
    angle += PI * 2.0;

  return angle;
}

Vector2D rotate(Vector2D vector, double radians) {
  final double cs = cos(radians);
  final double sn = sin(radians);

  final double px = vector.x * cs - vector.y * sn;
  final double py = vector.x * sn + vector.y * cs;

  return new Vector2D(px, py);
}

Vector2D project(Vector2D source, Vector2D target) {
  final double angle = angleBetween(source, target);
  return normalize(target) * (cos(angle) * source.length);
}
