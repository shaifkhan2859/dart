part of lostsouls;

class AnchorMan extends Body {
  final AudioManager _audioManager;
  final double standardForce = 10000.0;
  final double lookDistance = 300.0;
  final double anchorDistanceFactor = 0.5;

  Player targetPlayer;
  double targetMaxDistance;

  AnchorMan(final Vector2D position, final Vector2D lookDirection, this._audioManager) : super(24.0, position, new Vector2D.zero(), new Vector2D.zero(), lookDirection, PI * 0.8) {
    _collisionHandler = _handleCollisions;
  }

  void _handleCollisions(final Vector2D velocityBefore, final Vector2D velocityAfter) {
    if (velocityBefore.length > 12.0) {
      _audioManager.play("anchormanwallhit");
    }
  }

  bool _track(Player target, Level level, double elapsed) {
    final Segment toTarget = new Segment(position, target.position);

    bool canSeeTarget = toTarget.length < lookDistance;

    if (canSeeTarget) {
      for(int i = 0; i < level.walls.length; ++i) {
        final Segment wall = level.walls[i];
        final SegmentIntersection intersection = findIntersection(toTarget, wall);
        if (intersection.isIntersection && intersection.pointIsOnA && intersection.pointIsOnB) {
          canSeeTarget = false;
          break;
        }
      }
      final double angle = signedAngleBetween(lookDirection, toTarget.a2b);
      canSeeTarget = canSeeTarget && angle.abs() <= fieldOfView / 2.0;
      if (canSeeTarget) {
        if (toTarget.length < targetMaxDistance * anchorDistanceFactor) {
          targetPlayer = target;
          targetPlayer.addAnchorFactor(1.0 * (1.0 - (toTarget.length / targetMaxDistance * anchorDistanceFactor)));
          _audioManager.play("tractorbeam");
        }

        lookDirection = rotate(lookDirection, (targetPlayer != null ? 2.0 : 1.0) * 4.0 * 24 * angle * elapsed / (1 + size));
        if (toTarget.length > 2 * (target.size + size)) {
          final Vector2D force = this.lookDirection * (standardForce / (1 + size));
          forces.add(force);
        }
        return true;
      }
    }
    return false;
  }

  void processInput(double totalElapsed, double elapsed, Level level, List<Body> entities, Keyboard keyboard) {
    final Player player = entities.firstWhere((b) => b is Player);
    final Segment toTarget = new Segment(position, player.position);
    targetMaxDistance = 8 * (player.size + size);
    targetPlayer = null;
    if (toTarget.length < targetMaxDistance) {
      if (!_track(player, level, elapsed)) {
        lookDirection = rotate(lookDirection, (32 * 1 * elapsed / (1 + size)));
      }
    }
    else {
      lookDirection = rotate(lookDirection, (32 * 1 * elapsed / (1 + size)));
    }
  }

  void render(Renderer renderer) {
    if (targetPlayer != null) {
      final Segment toTarget = new Segment(position, targetPlayer.position);
      final double w = max(1.0, 16.0 * (1.0 - (toTarget.length / (targetMaxDistance * anchorDistanceFactor))));
      renderer.drawSegment(new Segment(position, targetPlayer.position), "black", w);
    }

    renderer.renderAnchorMan(this, 'black', 'white', 'black');
  }
}
