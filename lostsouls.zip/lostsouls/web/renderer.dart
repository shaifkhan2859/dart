part of lostsouls;

class Renderer {
  final CanvasRenderingContext2D context;
  final int _width;
  final int _height;
  double _previousGlobalAlpha = 1.0;

  Renderer(this.context, this._width, this._height);

  void pushGlobalAlpha(double alpha) {
    _previousGlobalAlpha = context.globalAlpha;
    context.globalAlpha = alpha;
  }

  void popGlobalAlpha() {
    context.globalAlpha = _previousGlobalAlpha;
  }

  void clip() {
    context.save();
    context.beginPath();
    context.rect(0, 0, _width, _height);
    context.clip();
  }

  void fillRect(final String fill, int width, int height) {
    context..beginPath()
           ..fillStyle = fill
           ..rect(0, 0, width, height)
           ..fill();
  }

  void fillFullRect(final String fill) {
    fillRect(fill, _width, _height);
  }

  void drawText(String text, String font, String fill, Vector2D position) {
    context..fillStyle = fill
           ..font = font
           ..fillText(text, position.x, position.y);
  }

  void fillCircle(Vector2D center, double radius, String fill) {
    context..beginPath()
           ..fillStyle = fill
           ..arc(center.x, center.y, radius, 0, PI * 2.0)
           ..fill();
  }

  void drawCircle(Vector2D center, double radius, String stroke) {
    context..beginPath()
           ..strokeStyle = stroke
           ..arc(center.x, center.y, radius, 0, PI * 2.0)
           ..stroke();
  }

  void drawSegment(Segment s, String stroke, double lineWidth) {
    context..beginPath()
           ..strokeStyle = stroke
           ..lineWidth = lineWidth
           ..moveTo(s._a.x, s._a.y)
           ..lineTo(s._b.x, s._b.y)
           ..stroke();
  }

  void fillPolygon(List<Vector2D> polygon, String fill) {
    final Vector2D start = polygon[0];
    context..fillStyle = fill
           ..beginPath()
           ..moveTo(start.x, start.y);

    for(var i = 1; i < polygon.length; ++i) {
      final Vector2D point = polygon[i];
      context.lineTo(point.x, point.y);
    }

    context..closePath()
           ..fill();
  }

  void clearAll(String color) {
    clear(_width, _height, color);
  }

  void clear(int w, int h, String color) {
    context..globalAlpha = 1
           ..fillStyle = color
           ..beginPath()
           ..rect(0, 0, w, h)
           ..fill();
  }

  void renderEyes(Body renderEntity, String eyes, String pupils) {
    var eyesCenter = renderEntity.position + (renderEntity.lookDirection * (renderEntity.size * 0.9));
    var left = eyesCenter + (cross(renderEntity.lookDirection) *  (renderEntity.size * 0.3));
    var right = eyesCenter + ((cross(renderEntity.lookDirection) * (-renderEntity.size * 0.3)));

    fillCircle(left, renderEntity.size * 0.25, eyes);
    fillCircle(right, renderEntity.size * 0.25, eyes);

    fillCircle(left, renderEntity.size * 0.10, pupils);
    fillCircle(right, renderEntity.size * 0.10, pupils);
  }

  void renderEntity(Body renderEntity, String base, String eyes, String pupils) {
    fillCircle(renderEntity.position, renderEntity.size, "white");
    fillCircle(renderEntity.position, renderEntity.size * 0.9, base);
    renderEyes(renderEntity, eyes, pupils);
  }

  void renderAnchorMan(AnchorMan man, String base, String eyes, String pupils) {

    context..beginPath()
           ..strokeStyle = "black"
           ..fillStyle = base
           ..lineWidth = 2.0;

    final double angle = man.lookDirection.angle;
    bool isFirst = true;
    final List<double> offsets = [-0.5, 0.5 ];

    final Random rnd = new Random((angle * 10.0).round());

    int c = 0;
    for(double r = angle; r < angle + 2.0 * PI; r += (2.0 * PI / 40.0)) {
      final Vector2D p = man.position + new Vector2D.polar(r, man.size + offsets[c % offsets.length] * man.size * 0.25 + offsets[c % offsets.length] * rnd.nextDouble() * 8.0);
      if (isFirst) {
        context.moveTo(p.x, p.y);
        isFirst = false;
      }
      else {
        context.lineTo(p.x, p.y);
      }
      ++c;
    }
    context.closePath();
    context.fill();

    renderEyes(man, eyes, pupils);
  }
}

