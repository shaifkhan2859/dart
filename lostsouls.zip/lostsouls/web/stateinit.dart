part of lostsouls;

class StateInit extends GameState {
  AudioManager _newAudioManager;
  double _readyTime = 2.0;

  StateInit(final Keyboard keyboard, final Renderer renderer, final AudioManager audioManager) : super(keyboard, renderer, audioManager) {
  }

  void _initialize() {
    querySelector("#areaGameTextInstruction").style.visibility = "visible";
    querySelector("#areaScoreB").style.visibility = "hidden";
    querySelector("#areaScoreT").style.visibility = "hidden";
  }

  GameState _update(double elapsed) {
    super._update(elapsed);
    if (_totalElapsed > _readyTime && _keyboard.isPressed(KeyCode.SPACE)) {
      querySelector("#areaGameTextInstruction").style.visibility = "hidden";
      return new StateGame(_keyboard, _renderer, _audioManager, 1);
    }
    return this;
  }

  void _render() {
    _renderer.clip();
    _renderer.clearAll(Colors.backgroundMain);
    if (_totalElapsed < _readyTime)
      querySelector("#areaGameTextMain").text = "LOST SOULS";
    else
      querySelector("#areaGameTextMain").text = "PRESS SPACE TO START";

    querySelector("#areaGameTextMain").style.visibility = "visible";
  }
}
