part of lostsouls;

class LostSoul extends Body {
  final AudioManager _audioManager;
  final double standardForce = 1500.0;
  final double lookDistance = 200.0;
  bool isSeeingTarget = false;

  LostSoul(final Vector2D position, final Vector2D lookDirection, final double size, this._audioManager) : super(size, position, new Vector2D(0.0, 0.0), new Vector2D(0.0, 0.0), lookDirection, PI) {
    restitution = 1.25;
  }

  bool _track(Body target, Level level, double elapsed) {
    final Segment toTarget = new Segment(position, target.position);

    bool canSeeTarget = toTarget.length < lookDistance;

    if (canSeeTarget) {
      for(int i = 0; i < level.walls.length; ++i) {
        final Segment wall = level.walls[i];
        final SegmentIntersection intersection = findIntersection(toTarget, wall);
        if (intersection.isIntersection && intersection.pointIsOnA && intersection.pointIsOnB) {
          canSeeTarget = false;
          break;
        }
      }
      final double angle = signedAngleBetween(lookDirection, toTarget.a2b);
      canSeeTarget = canSeeTarget && angle.abs() <= fieldOfView / 2.0;
      if (canSeeTarget) {
        lookDirection = rotate(lookDirection, (64 *angle* elapsed / (1 + size)));
        if (target is Home || toTarget.length > (size + target.size) * 2.5) {
          final Vector2D force = this.lookDirection * standardForce;
          forces.add(force);
        }

        return true;
      }
    }

    lookDirection = rotate(lookDirection, (32 * 0.22 * elapsed / (1 + size)));
    return false;
  }

  void processInput(double totalElapsed, double elapsed, Level level, List<Body> entities, Keyboard keyboard) {
    Body home = entities.firstWhere((b) => b is Home);


    if (new Segment(position, home.position).length < home.size) {
      size -= 4 * elapsed;
      if (size < 4)
        isDead = true;
    }
    else {
      var potentialTargets = [home, entities.firstWhere((b) => b is Player) ];
      bool seeingPlayer = false;

      if (_track(home, level, elapsed)) {
        isSeeingTarget = false;
      }
      else {
        if (_track(entities.firstWhere((b) => b is Player), level, elapsed)) {
          if (!isSeeingTarget)
            _audioManager.play("spottedbylostsoul");

          isSeeingTarget = true;
        }
        else
          isSeeingTarget = false;
      }
    }
  }

  void render(Renderer renderer) {
    renderer.renderEntity(this,  isSeeingTarget ? '#C00000' : '#A00000', '#FFFFFF', '#000000');
  }
}