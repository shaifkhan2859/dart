part of lostsouls;

/* Represents the (possible) intersection between two segments. */
class SegmentIntersection {
  final Segment a;
  final Segment b;
  final bool isIntersection;
  final Vector2D point;
  final bool pointIsOnA;
  final bool pointIsOnB;

  SegmentIntersection(this.a, this.b, this.isIntersection, this.point, this.pointIsOnA, this.pointIsOnB);

  String toString() {
    if (this.isIntersection) {
      return 'I[$a & $b $isIntersection @ $point A=$pointIsOnA B=$pointIsOnB]';
    }
    else {
      return 'I[$a & $b $isIntersection]';
    }
  }
}
