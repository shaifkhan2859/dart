part of lostsouls;

class StateLoad extends GameState {

  AudioManager _newAudioManager;

  double _loaded = 0.0;
  bool _fullyLoaded = false;
  double _readyTime = double.MAX_FINITE;

  StateLoad(final Keyboard keyboard, final Renderer renderer) : super(keyboard, renderer, null) {
    var clips =
        [ 
          new SoundClip("wallhit", "audio/73563__stanestane__bunny-push.wav", false),
          new SoundClip("anchormanwallhit", "audio/124382__cubix__8bit-snare.wav", false),
          new SoundClip("lostsouldsaved", "audio/153445__lukechalaudio__8bit-robot-sound.wav", false), //1.346s
          new SoundClip("tractorbeam", "audio/211235__rjonesxlr8__explosion-15.wav", true),
          new SoundClip("levelwon", "audio/211379__rjonesxlr8__coinpickup-06.wav", false),
          new SoundClip("gameover", "audio/213149__radiy__8bit-style-bonus-effect.wav", false),
          new SoundClip("music", "audio/166393__questiion__lost-moons-serious-as-an-attack-button.wav", true),
          new SoundClip("spottedbylostsoul", "audio/211325__rjonesxlr8__powerup-13.wav", false)
        ];

    _newAudioManager = new AudioManager(new AudioContext(),  clips, _onAudioLoaded, _onAllAudioLoaded);
  }

  void _onAudioLoaded(final double loaded) {
    _loaded = loaded;
  }

  void _onAllAudioLoaded(final List<SoundClip> buffers) {
  }

  GameState _update(double elapsed) {
    super._update(elapsed);

    if (_fullyLoaded)
      return new StateInit(_keyboard, _renderer, _newAudioManager);

    return this;
  }

  void _render() {
    _renderer.clip();
    _renderer.clearAll(Colors.backgroundMain);

    final int loadedPercentage = (_loaded * 100.0).toInt();
    final bool wasFullyLoaded = _fullyLoaded;
    _fullyLoaded = loadedPercentage == 100;

    querySelector("#areaGameTextMain").text = "LOADING ${loadedPercentage}%";
    querySelector("#areaGameTextMain").style.visibility = "visible";
  }
}
