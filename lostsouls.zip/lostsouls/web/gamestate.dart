part of lostsouls;

class GameState {
  final Keyboard _keyboard;
  final Renderer _renderer;
  final AudioManager _audioManager;
  double _totalElapsed = 0.0;

  GameState(this._keyboard, this._renderer, this._audioManager);

  void _initialize() {
  }

  GameState _update(final double elapsed) {
    _totalElapsed = _totalElapsed + elapsed;
    return this;
  }

  void _render() {
  }
}