library lostsouls;

import 'dart:collection';
import 'dart:async';
import 'dart:html';
import 'dart:math';
import 'dart:web_audio';

part 'keyboard.dart';
part 'vector2d.dart';
part 'segmentintersection.dart';
part 'segment.dart';
part 'body.dart';
part 'smoke.dart';
part 'player.dart';
part 'lostsoul.dart';
part 'anchorman.dart';
part 'home.dart';
part 'gamestate.dart';
part 'statefade.dart';
part 'stateload.dart';
part 'stateinit.dart';
part 'statenewlevel.dart';
part 'stategame.dart';
part 'stategameover.dart';
part 'level.dart';
part 'levelfactory.dart';
part 'gamecontroller.dart';
part 'renderer.dart';
part 'soundclip.dart';
part 'audiomanager.dart';

class Colors {
  static const String backgroundMain = "#7FA0F0";
  static const String backgroundGameOver = "#7F1020";
  static const String homeBorder = "white";
  static const String homeCenter = "green";
}

void main() {
  final DivElement mainDiv = querySelector("#areaMain");
  final CanvasElement canvas = querySelector("#gameCanvas");
  canvas.width = mainDiv.clientWidth;
  canvas.height = mainDiv.clientHeight;
  canvas.focus();
  scheduleMicrotask(new GameHost(canvas).start);
}

num fpsAverage;
void showFps(num n, num fps) {
  if (fpsAverage == null)
    fpsAverage = fps;

  fpsAverage = fps * 0.05 + fpsAverage * 0.95;
  querySelector("#areaFps").text = "${fpsAverage.round()} FPS";
}

class GameHost {
  CanvasElement canvas;
  int lastTimestamp = 0;
  num renderTime;
  Keyboard keyboard;
  GameState currentState;
  AudioManager audioManager;

  GameHost(this.canvas) {
    keyboard = new Keyboard();
    var renderer = new Renderer(canvas.context2D, canvas.width, canvas.height);
    currentState = new StateLoad(keyboard, renderer);
  }

  start() {
    requestRedraw();
  }

  void draw(num _) {
    final num time = new DateTime.now().millisecondsSinceEpoch;
    if (renderTime != null)
      showFps(_, 1000 / (time - renderTime));
    renderTime = time;

    double elapsed = 0.0;
    if (lastTimestamp != 0) {
      elapsed = (time - lastTimestamp) / 1000.0;
    }

    lastTimestamp = time;
    if (currentState != null) {
      var nextState = currentState._update(elapsed);
      currentState._render();
      if (currentState != nextState) {
        currentState = nextState;
        currentState._initialize();
      }
    }

    requestRedraw();
  }

  void requestRedraw() {
    window.requestAnimationFrame(draw);
  }
}