part of lostsouls;

class Home extends Body {
  Home(final Vector2D position) : super(64.0, position, new Vector2D.zero(), new Vector2D.zero(), new Vector2D(0.0, 1.0), 0.0);

  bool update(final double totalElapsed, final double elapsed, final Level level) {
    size = 92.0 + sin(totalElapsed * 3.0) * 12.0;
    return false;
  }

  void render(Renderer renderer) {
    renderer.fillCircle(position, size, Colors.homeBorder);
    renderer.fillCircle(position, size * 0.9, Colors.homeCenter);
  }
}