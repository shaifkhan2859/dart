part of lostsouls;

class StateNewLevel extends GameState {

  final double _timeThreshold = 3.0;
  final int _levelIndex;

  StateNewLevel(final Keyboard keyboard, final Renderer renderer, final AudioManager audioManager, this._levelIndex) : super(keyboard, renderer, audioManager);

  void _initialize() {
    querySelector("#areaTime").style.visibility = "hidden";
  }

  GameState _update(double elapsed) {
    super._update(elapsed);

    if (_totalElapsed > _timeThreshold && _keyboard.isPressed(KeyCode.SPACE))
      return new StateGame(_keyboard, _renderer, _audioManager, _levelIndex);

    return this;
  }

  void _render() {
    _renderer.clip();
    _renderer.clearAll(Colors.backgroundMain);

    if (_totalElapsed < _timeThreshold) {
      _audioManager.setGain("music", 1 - (_totalElapsed / _timeThreshold));
      querySelector("#areaGameTextMain").text = "LEVEL COMPLETED, ALL SOULS SAVED!";
    }
    else {
      _audioManager.stop("music");
      querySelector("#areaGameTextMain").text = "PRESS SPACE TO START LEVEL ${_levelIndex}";
    }
    querySelector("#areaGameTextMain").style.visibility = "visible";
  }
}